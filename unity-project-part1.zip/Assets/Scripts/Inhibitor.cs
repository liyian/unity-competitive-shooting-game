﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class Inhibitor : NetworkBehaviour {
	public const int maxResource_blue = 500;
	public const int maxResource_red = 500;
	[SyncVar(hook = "OnChangeBlueResource")]
	public int currentResource_blue = 0;
	[SyncVar(hook = "OnChangeRedResource")]
	public int currentResource_red = 0;
	public RectTransform resourceBar_blue;
	public RectTransform resourceBar_red;

	private List<Vector3> spawn_position = new List<Vector3>();
	[SyncVar(hook = "OnChangeFlag")]
	public bool do_change = true;

	// Use this for initialization
	void Start () {
		currentResource_blue = 0;
		resourceBar_blue.sizeDelta = new Vector2(currentResource_blue/5, resourceBar_blue.sizeDelta.y);
		currentResource_red = 0;
		resourceBar_red.sizeDelta = new Vector2(currentResource_red/5, resourceBar_red.sizeDelta.y);

		Vector3 position1 = new Vector3 (-55.0f, 2.0f, 0.0f);
		Vector3 position2 = new Vector3 (55.0f, 2.0f, 0.0f);
		Vector3 position3 = new Vector3 (0.0f, 2.0f, -59.0f);
		Vector3 position4 = new Vector3 (0.0f, 2.0f, 59.0f);

		spawn_position.Add (position1);
		spawn_position.Add (position2);
		spawn_position.Add (position3);
		spawn_position.Add (position4);
	}

	// Update is called once per frame
	void Update () {
		currentResource_blue = Mathf.RoundToInt(resourceBar_blue.sizeDelta.x*5);
		currentResource_red = Mathf.RoundToInt(resourceBar_red.sizeDelta.x*5);

		if (NetworkServer.connections.Count >= 2) {
			if (isServer) {
				if (do_change) {
					int index = Random.Range (0, 4);
					Vector3 new_position = spawn_position [index];
					Rpc_ChangePosition (new_position);
				}
			}
		}
	}

	void TakeResource_blue(int amount){
		if (!isServer)
			return;

		currentResource_blue += amount;
		if (currentResource_blue >= 500) {
			currentResource_blue = 500;
		}
	}

	void TakeResource_red(int amount){
		if (!isServer)
			return;

		currentResource_red += amount;
		if (currentResource_red >= 500) {
			currentResource_red = 500;
		}
	}

	void OnChangeBlueResource(int currentResource_blue){
		resourceBar_blue.sizeDelta = new Vector2(currentResource_blue/5, resourceBar_blue.sizeDelta.y);
	}

	void OnChangeRedResource(int currentResource_red){
		resourceBar_red.sizeDelta = new Vector2(currentResource_red/5, resourceBar_red.sizeDelta.y);
	}

	void OnChangeFlag(bool can_do){
		do_change = can_do;
	}

	void OnCollisionEnter(Collision other){
		var obj = other.gameObject;
		if (obj.CompareTag ("Player")) {
			var player = obj.GetComponent<PlayerController> ().player_name;
			var resource = obj.GetComponent<Resource> ();
			if (resource) {
				if (player == "player1") {
					TakeResource_blue (resource.currentResource);
					resource.GiveResource ();
				} 
				else if (player == "player2") {
					TakeResource_red (resource.currentResource);
					resource.GiveResource ();
				}
			}
		}
	}

	[ClientRpc]
	void Rpc_ChangePosition(Vector3 position){
		do_change = false;
		StartCoroutine(Wait(position));
	}

	IEnumerator Wait(Vector3 position){
		yield return new WaitForSeconds (30);
		transform.position = position;
		do_change = true;
	}
}
