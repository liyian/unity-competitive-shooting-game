﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PowerUp : MonoBehaviour {
	// Amount of the resource
	public int power = 5;
	// Private variable used to track time after being respawned
	private float start;


	// Use this for initialization
	void Start () {
		start = Time.time;
	}
	
	// Update is called once per frame
	void Update () {
		// Destroy resource after 30secs
		if(Time.time - start >= 30)
			Destroy(gameObject);
	}

	void OnTriggerEnter(Collider other){
		if (other.gameObject.CompareTag ("Player")) {
			var resource = other.gameObject.GetComponent<Resource> ();
			if (resource.currentResource < 100) {
				Destroy (gameObject);
			}
			if (resource) {
				resource.TakeResource (power);
			}
		}
	}
}
