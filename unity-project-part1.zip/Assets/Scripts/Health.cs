﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Networking;

public class Health : NetworkBehaviour {
	public const int maxHealth = 100;
	[SyncVar(hook = "OnChangeHealth")]
	public int currentHealth = maxHealth;
	public RectTransform healthBar;
	private Text text;
	private Renderer body;
	private Renderer visor;
	private Renderer left_arm;
	private Renderer right_arm;
	private Renderer hammer;
	private Renderer gun;
	private GameObject ui;
	private PlayerController myscript;

	float y_position;
	// Use this for initialization
	void Start () {
		// get all renders on the player object
		body = GetComponent<Renderer> ();
		myscript = GetComponent<PlayerController> ();
		visor = gameObject.transform.GetChild(0).GetComponent<Renderer> ();
		right_arm = gameObject.transform.GetChild(2).GetComponent<Renderer> ();
		hammer = gameObject.transform.GetChild(2).transform.GetChild(0).GetComponent<Renderer>();
		gun = gameObject.transform.GetChild(2).transform.GetChild(1).transform.GetChild(16).GetComponent<Renderer>();
		left_arm = gameObject.transform.GetChild(3).GetComponent<Renderer> ();
		ui = gameObject.transform.GetChild (5).gameObject;
		text = GameObject.Find("Canvas/Text").GetComponent<Text>();
		text.enabled = false;
		// save the y position (on the ground)
		y_position = transform.position.y;
	}
	
	// Update is called once per frame
	void Update () {

		// currentHealth equals to the width of health bar
		currentHealth = Mathf.RoundToInt(healthBar.sizeDelta.x);
	}

	public void TakeDamage(int amount){
		// do this on server
		if (!isServer)
			return;

		// decrease the current health by specific amount
		currentHealth -= amount;
		if (currentHealth <= 0){
			currentHealth = maxHealth;
			Rpc_Respawn ();
		}
	}

	void OnChangeHealth(int currentHealth){
		// if current health value changed, synchronize the size of health bar
		healthBar.sizeDelta = new Vector2(currentHealth, healthBar.sizeDelta.y);
	}

	[ClientRpc]
	void Rpc_Respawn(){
		// generate a random position
		float randX = Random.Range (-20.0f, 20.0f);
		float randZ = Random.Range (-20.0f, 20.0f);
		// set all renders to invisible
		body.enabled = false;
		myscript.enabled = false;
		visor.enabled = false;
		left_arm.enabled = false;
		right_arm.enabled = false;
		hammer.enabled = false;
		gun.enabled = false;
		ui.SetActive (false);
		transform.position = new Vector3 (randX, -10.0f, randZ);
		if (isLocalPlayer) {
			text.enabled = true;
		}
		// here is a waiting time
		StartCoroutine(Wait());
	}

	IEnumerator Wait(){
		// the waiting function, do everything below after 5 seconds
		yield return new WaitForSeconds (5);
		// set all renders to visible
		body.enabled = true;
		myscript.enabled = true;
		visor.enabled = true;
		left_arm.enabled = true;
		right_arm.enabled = true;
		hammer.enabled = true;
		gun.enabled = true;
		ui.SetActive (true);
		text.enabled = false;
		transform.position = new Vector3 (transform.position.x, y_position, transform.position.z);
		currentHealth = maxHealth;
	}
}
