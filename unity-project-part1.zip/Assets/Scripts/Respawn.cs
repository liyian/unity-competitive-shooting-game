﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class Respawn : NetworkBehaviour {
	public GameObject resourcePrefab;
	public GameObject AKPrefab;
    public int numberOfResources;
    
	// Position pool for resources
	private List<Vector2> resourceRespawnPosition = new List<Vector2>();
	// Position pool for weapons
	private List<Vector2> weaponRespawnPosition = new List<Vector2>();

    // Time track used for respawning
	private float timeTrack;

	// Use this for initialization
	public override void OnStartServer(){
		// Initialize resource spawning positions
		resourceRespawnPosition.Add(new Vector2(-7.0f, -9.0f));
		resourceRespawnPosition.Add(new Vector2(7.0f, 9.0f));
		resourceRespawnPosition.Add(new Vector2(7.0f, -9.0f));
		resourceRespawnPosition.Add(new Vector2(-7.0f, 9.0f));
		resourceRespawnPosition.Add(new Vector2(-28.0f, -37.0f));
		resourceRespawnPosition.Add(new Vector2(-37.0f, -37.0f));
		resourceRespawnPosition.Add(new Vector2(-33.0f, -48.0f));
		resourceRespawnPosition.Add(new Vector2(34.0f, -48.0f));
		resourceRespawnPosition.Add(new Vector2(41.0f, -37.0f));
		resourceRespawnPosition.Add(new Vector2(29.0f, -34.0f));
		resourceRespawnPosition.Add(new Vector2(28.0f, 37.0f));
		resourceRespawnPosition.Add(new Vector2(37.0f, 37.0f));
		resourceRespawnPosition.Add(new Vector2(33.0f, 48.0f));
		resourceRespawnPosition.Add(new Vector2(-34.0f, 48.0f));
		resourceRespawnPosition.Add(new Vector2(-37.0f, 34.0f));
		resourceRespawnPosition.Add(new Vector2(-29.0f, 34.0f));

        // Initialize weapon spawning positions
		weaponRespawnPosition.Add(new Vector2(0.0f, 0.0f));
		weaponRespawnPosition.Add(new Vector2(-30.0f, 0.0f));
		weaponRespawnPosition.Add(new Vector2(31.0f, 0.0f));
		weaponRespawnPosition.Add(new Vector2(-31.0f, 42.0f));
		weaponRespawnPosition.Add(new Vector2(35.0f, 43.0f));
		weaponRespawnPosition.Add(new Vector2(0.0f, 43.0f));
		weaponRespawnPosition.Add(new Vector2(35.0f, -41.0f));
		weaponRespawnPosition.Add(new Vector2(0.0f, -43.0f));
		weaponRespawnPosition.Add(new Vector2(-32.0f, -43.0f));

		timeTrack = 0;
		spawnObject(resourcePrefab, 10, resourceRespawnPosition);
		spawnObject(AKPrefab, 2, weaponRespawnPosition);
	}
	
	// Update is called once per frame
	void Update () {
		if(Time.time - timeTrack >= 30){
			timeTrack = Time.time;
			spawnObject(resourcePrefab, 10, resourceRespawnPosition);
			spawnObject(AKPrefab, 2, weaponRespawnPosition);
		}
	}
    
    /* Function that spawns different objects
     * Input: 
     *      obj: prefab that needs spawn
     *      num: number of spawn objects
     *      l: list of positions that used for spawning
    */
	void spawnObject(GameObject obj, int num, List<Vector2> l){
		if (!isServer)
			return;
        
		// Shuffle the list for randomly spawning resources
		List<Vector2> random = shuffelList(l);

		for (int i = 0; i < num; i++){
			var spawnRotation = Quaternion.Euler(
                                            0.0f,
                                            Random.Range(0, 180),
                                            0.0f);
			var spawnObj = (GameObject)Instantiate(obj, new Vector3(random[i][0],0.2f,random[i][1]), spawnRotation);
			NetworkServer.Spawn(spawnObj);
		}
	}

    // Helper function for shuffeling lists
	List<Vector2> shuffelList(List<Vector2> l){
		List<Vector2> temp = new List<Vector2>(l);
		for (int i = 0; i < temp.Count; i++)
        {
            Vector2 t = temp[i];
            int randomIndex = Random.Range(i, temp.Count);
            temp[i] = temp[randomIndex];
            temp[randomIndex] = t;
        }
		return temp;
	}
}
