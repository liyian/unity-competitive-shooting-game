﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;

public class PlayerController : NetworkBehaviour {
	public GameObject thisCamera;
	public GameObject hammerPrefab;
	public Transform hammerSpawn;
	public GameObject bulletPrefab;
	public Transform bulletSpawn;
	public float jump_force;
	[SyncVar(hook = "OnChangeName")]
	public string player_name;

	private Animator anim;
	private Rigidbody rb;
	private Text waiting_message;
	private RawImage minimap;
	private GameObject hammerMesh;
	private GameObject Gun;
	// Variable used for storing the beginning time
	private float start;
	// Private variable used to track time after being respawned
    private float time_track;
	Inhibitor score;
	Text time;
	private bool gameOver = false;

	public enum RotationAxes { MouseXAndY = 0, MouseX = 1, MouseY = 2 }
	public RotationAxes axes = RotationAxes.MouseX;
	public float sensitivityX = 2F;
	public float sensitivityY = 2F;
	public float minimumX = -360F;
	public float maximumX = 360F;
	public float minimumY = -60F;
	public float maximumY = 60F;
	float rotationY = 0F;

	[SyncVar(hook = "OnChangeFlag")]
	bool is_gun = false;
	// Use this for initialization
	void Start () {
		start = Time.time;
		time = GameObject.Find("Canvas/Timer").GetComponent<Text>();
		time.enabled = true;


		jump_force = 250.0f;
		rb = GetComponent<Rigidbody> ();
		anim = gameObject.GetComponent<Animator> ();
		minimap = GameObject.Find ("Canvas/Minimap").GetComponent<RawImage> ();
		minimap.enabled = true;
		waiting_message = GameObject.Find ("Canvas/Waiting").GetComponent<Text> ();
		hammerMesh = transform.GetChild (2).gameObject.transform.GetChild (0).gameObject;
		Gun = transform.GetChild (2).gameObject.transform.GetChild (1).gameObject;

		if (NetworkServer.connections.Count == 1) {
			player_name = "player1";
		} 
		else if (NetworkServer.connections.Count == 2) {
			player_name = "player2";
		}

		// if this player object is not local player do not do anything on it
        if (!isLocalPlayer)
        {
            thisCamera.SetActive(false);
        }

		time_track = Time.time;
		GameObject inhibitor = GameObject.Find("Inhibitor");
		score = inhibitor.GetComponent<Inhibitor>();
        
	}
	
	// Update is called once per frame
	void Update () {

		// detect if there are two player connect to server
		// if there is only one player, this player waiting for another connection
		// if there are two players, start game.
		if (isServer) {
			if (NetworkServer.connections.Count < 2) {
				Time.timeScale = 0;
				waiting_message.enabled = true;
			} 
			else {
				waiting_message.enabled = false;
				Time.timeScale = 1;
			}
		}

//		Time.timeScale = 1;           // for debug use

		if (gameOver)
			Time.timeScale = 0;

		// differenciate colors between players by check player's name
		if (player_name == "player1") {
			hammerMesh.GetComponent<Renderer> ().material.color = Color.blue;
		}
		else if (player_name == "player2") {
			hammerMesh.GetComponent<Renderer> ().material.color = Color.red;
		}

		// Every 30 secs the players are forced to abandon their super weapons
		if (Time.time - time_track >= 30)
        {
			time_track = Time.time;
            if (isServer)
                Rpc_setHammer();
        }

		float now = 360 - Time.time + start + 1;
		float minutes, seconds;
		minutes = (int)(now / 60f);
		seconds = (int)(now % 60f);
		time.text = minutes.ToString("00") + ":" + seconds.ToString("00");

		if (now <= 0)
		{
			gameOver = true;
			waiting_message.enabled = true;
			waiting_message.fontSize = 15;

			if (score.currentResource_red > score.currentResource_blue)
			{
				waiting_message.text = "GameOver" + System.Environment.NewLine +
					  "red " + score.currentResource_red + System.Environment.NewLine +
					  "blue " + score.currentResource_blue + System.Environment.NewLine +
					  "red win";
			}
			else if (score.currentResource_red == score.currentResource_blue)
			{
				waiting_message.text = "GameOver" + System.Environment.NewLine +
					  "red " + score.currentResource_red + System.Environment.NewLine +
					  "blue " + score.currentResource_blue + System.Environment.NewLine +
					  "no one win";
			}
			else if (score.currentResource_red < score.currentResource_blue)
			{
				waiting_message.text = "GameOver" + System.Environment.NewLine +
					  "red " + score.currentResource_red + System.Environment.NewLine +
					  "blue " + score.currentResource_blue + System.Environment.NewLine +
					  "blue win";
			}
		}


		// if this player object is not local player do not do anything on it
		if (!isLocalPlayer)
			return;

		// if player press "c" on the keyboard, attack
		if (Input.GetMouseButtonDown(0) && Time.timeScale != 0){
			anim.Play ("arm_mov");   
			Cmd_Fire ();
		}

	}

	void FixedUpdate(){

		// if this player object is not local player do not do anything on it
		if (!isLocalPlayer) {
			return;
		}

		// press "space" for jump
		if(Input.GetKeyDown(KeyCode.Space)){
			if (Mathf.Abs (rb.velocity.y) < 0.00001) {
				rb.AddForce (new Vector3 (0.0f, 1.0f, 0.0f) * jump_force);
			}
		}

		// player's basic movement
		var x = Input.GetAxis("Horizontal") * Time.deltaTime * 5.0f;
		var z = Input.GetAxis("Vertical") * Time.deltaTime * 5.0f;

//		transform.Rotate(0, x, 0); 
		transform.Translate(x, 0, 0);
		transform.Translate(0, 0, z);
        
		if (transform.position.y < 0.5)
			transform.Translate(0, 1, 0);

		if (axes == RotationAxes.MouseXAndY)
		{
			float rotationX = transform.localEulerAngles.y + Input.GetAxis("Mouse X") * sensitivityX;

			rotationY += Input.GetAxis("Mouse Y") * sensitivityY;
			rotationY = Mathf.Clamp (rotationY, minimumY, maximumY);

			transform.localEulerAngles = new Vector3(-rotationY, rotationX, 0);
		}
		else if (axes == RotationAxes.MouseX)
		{
			transform.Rotate(0, Input.GetAxis("Mouse X") * sensitivityX, 0);
		}
		else
		{
			rotationY += Input.GetAxis("Mouse Y") * sensitivityY;
			rotationY = Mathf.Clamp (rotationY, minimumY, maximumY);

			transform.localEulerAngles = new Vector3(-rotationY, transform.localEulerAngles.y, 0);
		}
        
	}


	// Command function send from client to server
	[Command]
	void Cmd_Fire(){
		GameObject prefab;
		Transform spawn;
		float time;
		int velocity;

		// if the flag is set to is_gun, player has gun now so change the hammerPrefab to bulletPrefab
		if (is_gun) {
			prefab = bulletPrefab;
			spawn = bulletSpawn;
			time = 3.0f;
			velocity = 30;
		} 
		else {
			prefab = hammerPrefab;
			spawn = hammerSpawn;
			time = 1.5f;
			velocity = -12;
		}

		// generate a GameObject based on prefab and spawn position
		var obj = (GameObject)Instantiate (prefab, spawn.position, spawn.rotation);
		// bullet and hammer have different move directions
		if (is_gun) {
			obj.GetComponent<Rigidbody> ().velocity = obj.transform.up * velocity;
		} 
		else {
			obj.GetComponent<Rigidbody> ().velocity = obj.transform.forward * velocity;
		}
		NetworkServer.Spawn (obj);
		Destroy (obj, time);
	}

	void OnChangeName(string name){
		// if server assigned players' name, sychronize the name on clients
		if (name == "player1") {
			player_name = name;
		} 
		else if (name == "player2") {
			player_name = name;
		}
	}

	void OnChangeFlag(bool flag){
		// if "is_gun" flag changed on server, sychronize the flag on clients 
		// (not sure if this sychronization is required)
		is_gun = flag;
	}

	[ClientRpc]
	void Rpc_setGun(){
		// change players' hammer mesh to gun mesh, send from server to clients
		hammerMesh.SetActive (false);
		Gun.SetActive (true);
	}
    
	[ClientRpc]
    void Rpc_setHammer()
    {
        // change players' gun mesh to hammer mesh, send from server to clients
		hammerMesh.SetActive(true);
		Gun.SetActive(false);
		is_gun = false;
    }

	void OnCollisionEnter(Collision other){
		// if player touched gun on the map, they can now use it
		GameObject obj = other.gameObject;
		if (obj.CompareTag ("gun") && is_gun == false) {
			Destroy (obj);
			is_gun = true;
			if (isServer) {
				// set up the gun from server
				Rpc_setGun ();
			}
		}
	}

}
