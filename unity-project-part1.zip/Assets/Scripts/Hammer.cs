﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class Hammer : MonoBehaviour {
	bool collide;
	// Use this for initialization
	void Start () {
		collide = false;
		gameObject.GetComponent<Rigidbody> ().useGravity = true;
	}
	
	// Update is called once per frame
	void Update () {
		if (!collide) {
			transform.Rotate(Vector3.right * -20);
		}
	}

	void OnCollisionEnter(Collision other){
		collide = true;
		var hit = other.gameObject;
		// if hammer hit player, player will take damage
		if (hit.CompareTag ("Player")) {
			var health = hit.GetComponent<Health> ();
			if (health) {
				health.TakeDamage (8);
			}
			// if hit player, destroy the hammer
			Destroy (gameObject);
		}
		// if hit something, destroy the hammer
		Destroy (gameObject);
	}
}
