﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bullet : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void OnCollisionEnter(Collision other){
		var hit = other.gameObject;
		// if bullet hit player, player will take damage
		if (hit.CompareTag ("Player")) {
			var health = hit.GetComponent<Health> ();
			if (health) {
				health.TakeDamage (10);
			}
			// if hit player, destroy the bullet
			Destroy (gameObject);
		}
		// if hit something, destroy the bullet
		Destroy (gameObject);
	}
}
