﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class Resource : NetworkBehaviour {
	public const int maxResource = 100;
	[SyncVar(hook = "OnChangeResource")]
	public int currentResource;
	public RectTransform resourceBar;
	// Use this for initialization
	void Start () {
		resourceBar.sizeDelta = new Vector2(currentResource, resourceBar.sizeDelta.y);
	}
	
	// Update is called once per frame
	void Update () {
		currentResource = Mathf.RoundToInt(resourceBar.sizeDelta.x);
	}

	public void TakeResource(int amount){
		if (!isServer)
			return;

		currentResource += amount;
		if (currentResource >= 100) {
			currentResource = 100;
		}
	}

	public void GiveResource(){
		if (!isServer)
			return;

		currentResource = 0;
	}

	void OnChangeResource(int currentResource){
		resourceBar.sizeDelta = new Vector2(currentResource, resourceBar.sizeDelta.y);
	}
}
